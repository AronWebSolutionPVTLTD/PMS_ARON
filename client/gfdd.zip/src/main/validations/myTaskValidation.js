
const myTaskValidation = {
    todo: "doit etre definie",
    due_date: "doint etre definie",
}
export default myTaskValidation;