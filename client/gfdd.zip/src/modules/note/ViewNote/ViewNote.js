import React from 'react';
import PropTypes from 'prop-types';
import './ViewNote.css';

const ViewNote = () => (
  <div className="ViewNote">
    ViewNote Component
  </div>
);

ViewNote.propTypes = {};

ViewNote.defaultProps = {};

export default ViewNote;
