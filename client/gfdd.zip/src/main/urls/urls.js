const BASE_URL = "https://pms-dnxf.onrender.com/api/v2"

export default BASE_URL
