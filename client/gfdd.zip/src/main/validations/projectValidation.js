const projectValidation = {
    title: "title is required",
    description: "description is required",
    starting_date: "starting date is required",
    ending_date: "ending date is required",
    users: "users is required ",
    client: "client is required"
}
export default projectValidation;