
const noteValidation = { description: "description is required.", }
export default noteValidation;