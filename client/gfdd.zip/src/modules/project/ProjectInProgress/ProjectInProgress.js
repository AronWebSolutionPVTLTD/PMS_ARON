import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import './ProjectInProgress.css';
import projectHTTPService from '../../../main/services/projectHTTPService';

const ProjectInProgress = () => {

  
  return (
    <div class="col-lg-6 col-xl-12">
   
    </div>
  )
};

ProjectInProgress.propTypes = {};

ProjectInProgress.defaultProps = {};

export default ProjectInProgress;
