
const taskValidation = {
    project_id: "project is required.",
    description: "description is required.",
    title: "title is required.",
    due_date: "due date is required.",
    priority: "priority is required.",
    status: "status is required.",
    users: "user is required."
}
export default taskValidation;