
const userValidation = {
    first_name: "First name is required.",
    last_name: "Last name is required.",
    email: "Email is required.",
    phone: "Telephone is required.",
    password: "password is required.",
    groups: "group is required."
}
export default userValidation;