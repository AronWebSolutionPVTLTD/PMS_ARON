const userMessage = {
    add: 'Email has been sent to your registered mail. Please verify!',
    edit: 'User has been successfully edited',
    delete: 'User has been successfully removed'
}

export default userMessage

