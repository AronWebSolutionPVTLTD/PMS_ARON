
const interviewValidation = {
    title: "doit etre definie",
    destination: "doit etre definie",
    message: "doit etre definie",
}
export default interviewValidation;