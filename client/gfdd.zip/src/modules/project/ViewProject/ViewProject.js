import React from 'react';
import PropTypes from 'prop-types';
import './ViewProject.css';

const ViewProject = () => (
  <div className="ViewProject">
    ViewProject Component
  </div>
);

ViewProject.propTypes = {};

ViewProject.defaultProps = {};

export default ViewProject;
