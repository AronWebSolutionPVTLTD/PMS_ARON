$(function () {
    const choices = new Choices("select", {
        removeItems: true,
        removeItemButton: true
    });

})